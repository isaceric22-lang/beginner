<div align="center">

# 💍 The Wedding of **Dian & Iqbal**

**Digital Wedding Invitation** — Sunday, 10 January 2027 • Pekanbaru, Riau

A grand maroon, saffron & gold Indian wedding design with an animated Ganesha, marigold garlands, and diyas.

<img src="https://img.shields.io/badge/HTML5-E34F26?style=flat-square&logo=html5&logoColor=white" alt="HTML5">
<img src="https://img.shields.io/badge/CSS3-1572B6?style=flat-square&logo=css3&logoColor=white" alt="CSS3">
<img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=flat-square&logo=javascript&logoColor=black" alt="JavaScript">
<img src="https://img.shields.io/badge/GitHub%20Pages-Ready-222222?style=flat-square&logo=github&logoColor=white" alt="GitHub Pages">
<img src="https://img.shields.io/badge/Mobile--First-Responsive-9c5f66?style=flat-square" alt="Responsive">

**[✨ Preview](#-preview)** • **[🚀 Publishing](#-publishing-the-website)** • **[✏️ Editing](#%EF%B8%8F-editing-the-invitation)**

</div>

---

## 📑 Table of Contents

1. [About](#-about)
2. [Features](#-features)
3. [Preview](#-preview)
4. [Project Structure](#-project-structure)
5. [Running Locally](#-running-locally)
6. [Publishing the Website](#-publishing-the-website)
7. [Editing the Invitation](#%EF%B8%8F-editing-the-invitation)
8. [Sending the Invitation to Guests](#-sending-the-invitation-to-guests)
9. [Background Music](#-background-music)
10. [Saving Guest Wishes to Google Sheets (Optional)](#-saving-guest-wishes-to-google-sheets-optional)
11. [FAQ](#-faq)
12. [Credits](#-credits)

---

## 📖 About

A digital wedding invitation website designed **primarily for phones** (it still looks good on
desktop). Guests receive a **link** — when opened, they see the invitation cover with **their own
name**, tap *Open Invitation*, and the music starts.

Built **without any framework** (plain HTML + CSS + JavaScript), so it is lightweight, fast, and
can be hosted **for free** on GitHub Pages or Vercel — no build step required.

| Detail | Information |
|---|---|
| Bride | Dian Ayu Puspa Sari (Pekanbaru, 10 September 2005) |
| Groom | Iqbal Pradana (3 May 1997) |
| Wedding Day | **Sunday, 10 January 2027** |
| Location | Air Putih Village, Tuah Madani, Pekanbaru City, Riau (Plus Code `F9M2+C8`) |
| Design Theme | Maroon + saffron + gold ✨, detailed Ganesha line art, temple arch, mandala, marigold toran, lotus & diya ornaments |

## ✨ Features

| Feature | Description |
|---|---|
| 💌 **Automatic guest name** | Each guest's link shows their name, e.g. `site.com/?to=Budi` → cover reads "Dear … Budi" |
| 🎵 **Automatic music** | *Aaj Sajeya* (Goldie Sohel) plays when the invitation is opened, with a floating play/pause button |
| ⏳ **Countdown** | Live days/hours/minutes/seconds countdown to the wedding day |
| 🪔 **Grand animations** | Gold-shimmering Ganesha with a glow, temple-arch cover, rotating mandala, swaying marigold toran with bells, flickering diyas, shimmering names, falling marigold petals |
| 🗺️ **Location & map** | Full address, embedded Google Map, *Open Google Maps* button, and *Save to Google Calendar* button |
| 🖼️ **Photo gallery** | Masonry layout; photos open in a lightbox with left/right navigation |
| 📝 **RSVP & wishes** | Guests confirm attendance and leave wishes, shown on the page immediately |
| 🔥 **Wedding rituals** | Animated timeline of Haldi, Mehendi, Sangeet, Baraat, Varmala, Kanyadaan, Saat Phere and Vidaai, on frosted-glass cards |
| 🎉 **All festivities** | Haldi, Mehendi, Sangeet, Wedding Ceremony (Pheras) and Reception cards |
| 📱 **Navigation dock** | Floating dock at the bottom of the screen to jump between sections |

## 🖼️ Preview

Screenshots of the original (pre-redesign) site, tested at a 390×844 phone viewport:

| Cover + guest name | Countdown | Bride & groom |
|:---:|:---:|:---:|
| <img src="docs/screenshots/01-cover.png" width="220" alt="Invitation cover"> | <img src="docs/screenshots/02-hitung-mundur.png" width="220" alt="Countdown"> | <img src="docs/screenshots/03-mempelai.png" width="220" alt="Bride and groom"> |

| Event details | Gallery | |
|:---:|:---:|:---:|
| <img src="docs/screenshots/04-acara.png" width="220" alt="Event details"> | <img src="docs/screenshots/05-galeri.png" width="220" alt="Gallery"> | |

> All screenshots are in [`docs/screenshots/`](docs/screenshots/).

## 📁 Project Structure

```
undangan-dian-iqbal/
├── index.html      ← The whole site in one file: content, styles (<style>), and script (<script>, incl. CONFIG)
├── 404.html        ← GitHub Pages: redirects site.com/GuestName to ?to=GuestName
├── .nojekyll       ← Tells GitHub Pages to serve files as-is
├── vercel.json     ← Vercel: guest-name links (site.com/GuestName)
├── docs/           ← Screenshots for this documentation
└── README.md       ← This guide
```

## 💻 Running Locally

Double-click `index.html` to open it in a browser — no server needed. An internet connection is
required for fonts, photos, the map, and music.

Note: YouTube refuses to play music on a page opened by double-click (`file://`). It plays normally
once the site is on GitHub Pages. To hear music locally, set `CONFIG.audioFile` (see Background Music).

## 🚀 Publishing the Website

All options below are **free**.

### Option 1 — GitHub Pages

1. In the GitHub repository, go to **Settings → Pages**.
2. *Source*: **Deploy from a branch** → choose branch `main` and folder `/ (root)` → **Save**.
3. Wait about a minute. Your link: `https://USERNAME.github.io/undangan-dian-iqbal/`
4. Guest links: `.../undangan-dian-iqbal/?to=Budi` or `.../undangan-dian-iqbal/Budi`
   (the second format is redirected automatically by `404.html`).

### Option 2 — Vercel without GitHub (about 2 minutes)

1. Open **[vercel.com/new](https://vercel.com/new)** and sign in.
2. **Drag & drop** the whole project folder onto the deploy area.
3. Wait about 30 seconds until **Congratulations** appears.
4. Done. Your link looks like: `https://undangan-dian-iqbal.vercel.app`

### Option 3 — GitHub + Vercel (automatic updates)

1. Open **[vercel.com/new](https://vercel.com/new)**.
2. Click **Import Git Repository** → choose the `undangan-dian-iqbal` repo.
3. Leave all settings as they are → click **Deploy**.
4. Done. **Bonus:** every change pushed to GitHub updates the website automatically.

> 🌐 **Want a custom domain?** For example `wedding.dianiqbal.com` — set it up under
> *Settings → Pages → Custom domain* (GitHub) or *Project → Settings → Domains* (Vercel).
> Domains are paid separately.

## ✏️ Editing the Invitation

Open the relevant file in any text editor (Notepad works, but
[VS Code](https://code.visualstudio.com) is recommended), find the text, save, and re-upload.

| What to change | File | How |
|---|---|---|
| 🕐 **Event dates & times** | `index.html` | Search for `Haldi`, `Mehendi`, `Sangeet`, `Pheras`, `Reception` and edit |
| 🔥 **Ritual descriptions** | `index.html` | Search for `ritual-name` |
| 📝 **Names & bios** | `index.html` | Search for `Dian` / `Iqbal` |
| 🖼️ **Photos & gallery** | `index.html` | Replace the `https://i.pinimg.com/...` URLs with your own photo URLs (must be online, or a file inside this repo) |
| 🎵 **Song** | `index.html` | `CONFIG.youtubeVideoId` — the 11-character code from a YouTube link (e.g. `youtube.com/watch?v=`**`boeim-VkxN4`**) |
| 🎨 **Theme colors** | `index.html` | `:root` section at the top of the `<style>` block (`--rose-500`, `--gold-500`, etc.) |

> ⚠️ **Important before sharing:** the Haldi, Mehendi and Sangeet dates/times are
> **placeholders** — replace them with the real schedule first!

## 💌 Sending the Invitation to Guests

Add the guest's name to the end of the link:

| Format | Example |
|---|---|
| **With `?to=`** *(recommended, works everywhere)* | `https://your-site/?to=Budi%20Santoso` |
| **With a slash** | `https://your-site/Budi-Santoso` |

Notes:

- Write spaces as `%20` (format 1) or use a hyphen `-` (format 2) — both appear as spaces.
- WhatsApp example:
  `Dear Mr. Budi, we would be honored by your presence at our wedding 🌸 https://your-site/?to=Mr.%20Budi`
- If the link has **no** name, the cover shows "Honored Guest".

## 🎵 Background Music

The song plays directly from **YouTube** (*Aaj Sajeya* by Goldie Sohel) using a hidden player,
so no MP3 file is needed and the site stays small.

**Own audio file (optional):** put an audio file you have the rights to (e.g. `music.mp3`) next to
`index.html` and set `CONFIG.audioFile: "music.mp3"`. It then replaces YouTube and also plays when
`index.html` is opened by double-click. Commit the file too when publishing to GitHub Pages.

Note: some phones (especially iPhones) restrict autoplay — so the music intentionally starts when
the guest **taps "Open Invitation"** (a tap counts as permission for the browser). The floating
**play/pause** button stays available in the top right.

## 📊 Saving Guest Wishes to Google Sheets (Optional)

Currently each guest's wish is stored only on that guest's own device. To **collect all wishes in
one spreadsheet**:

1. Create a new Google Sheet → **Extensions → Apps Script**.
2. Paste the code below, replacing `REPLACE_WITH_SHEET_ID` with your Sheet ID (the string in the
   sheet URL between `/d/` and `/edit`):

   ```js
   function doPost(e) {
     const sh = SpreadsheetApp.openById('REPLACE_WITH_SHEET_ID').getSheets()[0];
     const d = JSON.parse(e.postData.contents);
     sh.appendRow([new Date(), d.name, d.attend, d.guests, d.message]);
     return ContentService.createTextOutput(JSON.stringify({ ok: true }))
       .setMimeType(ContentService.MimeType.JSON);
   }
   ```

3. Click **Deploy → New deployment → Web app** → *Who has access*: **Anyone** → copy the `/exec` URL.
4. Open `index.html`, paste the URL into `CONFIG.rsvpWebAppUrl` (starting with `https://`), and redeploy.

Every wish now goes into the sheet with timestamp, name, attendance, guest count, and message.

## ❓ FAQ

<details>
<summary><b>Why is there no music?</b></summary>

Make sure the phone volume is on and not in silent mode. On iPhone, music starts after tapping
"Open Invitation". If it still does not play, tap the music button (note icon) in the top right.
YouTube music does not play when the file is opened directly from your computer; it works on GitHub
Pages, or locally if you set `CONFIG.audioFile`.
</details>

<details>
<summary><b>The guest name does not appear on the cover?</b></summary>

Check the link — it needs <code>?to=Name</code> at the end, e.g.
<code>?to=Budi%20Santoso</code>. Without it, the cover shows "Honored Guest".
</details>

<details>
<summary><b>Can I use my own gallery photos?</b></summary>

Yes. Replace the image URLs in the gallery section of <code>index.html</code> with your own online
photo URLs. Local photos can be added to this repo and referenced by path.
</details>

<details>
<summary><b>Is hosting free forever?</b></summary>

Yes. GitHub Pages and Vercel both host static sites like this one for free. Only a custom domain
costs money.
</details>

<details>
<summary><b>How do I address a guest as "The Family of Mr. X"?</b></summary>

Write it in the link: <code>?to=The%20Family%20of%20Mr.%20X</code> — letters and numbers are safe to use.
</details>

## 🙏 Credits

- **Fonts** — [Cormorant Garamond](https://fonts.google.com/specimen/Cormorant+Garamond),
  [Great Vibes](https://fonts.google.com/specimen/Great+Vibes),
  [Plus Jakarta Sans](https://fonts.google.com/specimen/Plus+Jakarta+Sans),
  [Cinzel](https://fonts.google.com/specimen/Cinzel) via Google Fonts.
- **Ganesha artwork** — [Ganesha by j4p4n on Openclipart](https://openclipart.org/detail/344359/ganesha),
  public domain (CC0); embedded in `index.html` as a gold-tinted mask.
- **Music** — *Aaj Sajeya* — Goldie Sohel (played via YouTube).
- **Photos** — sourced from [Pinterest](https://pinterest.com) for demonstration purposes; all
  rights belong to their respective owners. Please replace them with your own photos.
- **Icons & ornaments** — custom SVGs: mandala, temple arch, lotus, diyas, marigold flowers, mango leaves, bells.

---

<div align="center">

**Dian ❤️ Iqbal** — 10 . 01 . 2027

*This invitation was made with love and prayers.* 🤍

</div>
